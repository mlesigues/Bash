#!/bin/bash
# Name: Marielle Lesigues
# File name: library.sh
# Date: 12/12/21
# Desc: File that contains 4 functions, each function will be explain below

# Function: join_with
# Desc: joins positional parameters with any character passed to it (as the connector)
join_with() {
	#check if user input argumemnts
        if [[ $# -gt 0 ]]
        then
            	printf "%sPerforming the task.\n"
        else
            	printf "%sThere are no arguments! Try again\n"
                return
        fi

	#the task
        local IFS="$1"
        shift
	echo "$*"
        items="Item Item Item"
}

# Function: cube
# Desc: cubes the numbers given to it (can handle any number of arguments)
cube() {
	#if the user enter nothing, print a usage error message & return
        if [[ $# -le 0 ]]
        then
            	printf "%sUsage:cube number_one number_two number_so_on\n"

        #if the user only enters 1 number
        elif [[ $# -eq 1 ]]
        then
            	output=$1*$1*$1
                output=$((output))
                printf "%n$1 %scubed:\t\t\t%n$output\n"
        else
            	#link: https://stackoverflow.com/questions/255898/how-to-iterate-over-arguments-in-a-bash-script

                for elem in "$@"
                do
                  	cubeoper=$elem*$elem*elem
                        cubeoper=$((cubeoper))
                        printf "%n$elem %scubed:\t\t\t%n$cubeoper\n"
                done
        fi
}

# Function: chg_case
# Desc: converts a string to all uppercase or lowercase and/or accepts input on the command line and
# from a pipe
chg_case() {
	if [[ $# -eq 1 ]] #read from piped arguments
	then
		while read -r data
		do
			#read the first argument (positional parameters)
			if test "$1" == "tolower"
			then
				printf "%s${data,,}\n"
			elif test "$1" == "toupper"
			then
				printf "%s${data^^}\n"
			else
			printf "Usage: echo string_one string_so_on | chg_case toupper_or_tolower\n"
			fi
		done

	#read from user's given argument
	elif test "$1" == "tolower"
	then
		shift
		for arg
		do
			printf "%s${arg,,} "
		done

	printf "\n"

	#read from user's given argument
	elif test "$1" == "toupper"
	then
		shift
		for arg
		do
			printf "%s${arg^^} "
		done

	printf "\n"

	else
		printf "%sUsage: chg_case tolower_or_toupper string_one string_two string_so_on"

	fi
}


# Function: go2
# Desc: cd's to a subdirectory. Assumed that you have a directory named "public_html" and it has 3 subdirectories
# and each has 8 subdirectories, all with the same names.
go2() {
	#$1 = subdirectory (python, ruby & shell)
	#$2 = suddirectory of $1, it would be named 1..8

	#cd/public_html/$1/$2

	#[mlesigu1@hills ~]$ cd cs160b/7/public_html

	#cs="cs160b"
	#week="7"
	par_dir="public_html"
	subdir=$1
	childsub_dir=$2

	#cd $HOME/$cs/$week/$par_dir/$subdir/$childsub_dir

	cd $HOME/$par_dir/$subdir/$childsub_dir

 	#check if we got the right directory & to be deleted/commented
	echo $(pwd)
}


# Function: chmod_remote
# Desc: set the permissions of a directory or a file on a remote server such as Hills
chmod_remote() {
	#$1 = server name
	#$2 = user name
	#$3 = octal permissions
	#$4 = path to the target file

	#if a user enter an incorrect number of parameters, return an error status. Use return, not exit

	if [[ $# -eq 4 ]]
	then
		ssh $2@$1 chmod $3 $4
	else
		return
	fi
}


